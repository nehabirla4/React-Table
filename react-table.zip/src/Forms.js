import React from 'react'

export const Forms = () => {
  return (
    <div>Forms</div>
  )
}
