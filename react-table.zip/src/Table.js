import React, { useEffect, useState } from 'react'

export const Table = () => {

  function Delete(e,id){
    //  tableRows.forEach(element =>  element.id !== id);
      //  console.log("The Table Row",tableRows);
    console.log(e);
    console.log("fun",id);
    let index = tabledata
            .map(function (e) {
                return e.id;
            })
            .indexOf(id);
            tabledata.splice(index, 1);
            console.log(tabledata)
    // tableRows.forEach(element =>  element.id !== id);
    // console.log(e.target.value);
   }
  

const tabledata=JSON.parse(localStorage.getItem("localList"));
console.log("table data",tabledata);
   const tableRows = tabledata.map((info) => {
    return (
        <tr >
            <td>{info.name}</td>
            <td>{info.email}</td>
            <td>{info.dob}</td>
            <td>{info.date}</td>
            <td>
          <button className='rounded-xl bg-red-500 px-2 py-1' onClick={(e)=>Delete(info.id)}>Delete</button> 
          <button className='rounded-xl bg-yellow-500 px-2 py-1 ms-2'>Edit</button>
            </td>
        </tr>
    );
});


    // var finalArray = tabledata.map(function (obj) {
    //   return obj.id;
    // });
    // console.log("finalArray",finalArray);
  return (
    <>
    <div >
      {/* <input type="date" max={getCurrent()}></input> */}
    <button className="px-5 py-2 rounded-lg mb-2 bg-violet-800 text-white">Edit</button>
    <table class="table table-dark table-striped-columns">
       <thead>
         <tr>
            
            <th>Name</th>
            <th>Email</th>
            <th>DOB</th>
            <th>Date</th>
            <th>Action</th>
         </tr>
       </thead>
    {/* <tbody>{tableRows}</tbody> */}
    <tbody>{ tabledata.map((info) => {
    return (
        <tr >
            <td>{info.name}</td>
            <td>{info.email}</td>
            <td>{info.dob}</td>
            <td>{info.date}</td>
            <td>
          <button className='rounded-xl bg-red-500 px-2 py-1' onClick={(e)=>Delete(info.id)}>Delete</button> 
          <button className='rounded-xl bg-yellow-500 px-2 py-1 ms-2'>Edit</button>
            </td>
        </tr>
    );
})}</tbody>
    </table>
    </div>
    </>
  )
}
