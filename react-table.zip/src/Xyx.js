import React, { useEffect, useState, useRef } from "react";
import { InputText } from "./InputText";
import { useNavigate } from "react-router-dom";
import { v4 as uuid } from "uuid";
let dataList=[];
dataList=JSON.parse(localStorage.getItem("localList"));
export const Xyx = () => {

  const navigate = useNavigate();
  const initialdata = {
    id: "",
    name: "",
    email: "",
    address: "",
    dob: "",
    dates: "",
    gender: "",
    image: "",
    age: "",
    isdob: false,
    dobval: "",
  };
  const [fromval, setVal] = useState(initialdata);
  // const [dataList, setarr] = useState([]);
  const [isShow, setIsShow] = useState(false);
  const idRef = useRef(fromval.id);
  let formActual;
  const Onchange = (e) => {
    const { name, value } = e.target;
    console.log("name", name);
    console.log("val", value);
    // setVal({
    //   ...fromval,
    //   [name]: value,
    // });

    if (value == "dob") {
      console.log("if");
      setVal({
        ...fromval,
        isdob: true,
        // isdob: fromval.isdob,
      });
      // setIsShow(true)
      //  fromval.isdob=true;
    } else {
      console.log("else");
      // setIsShow(false)
      setVal({
        ...fromval,
        isdob: false,
        //  isdob: fromval.isdob,
        [name]: value,
      });
    }
    console.log("dob:", fromval.isdob);
  };

  function uidfun() {
    let guid = uuid();
    let ans = String(guid);
    //   console.log(ans);
    //  setVal({
    //   ...fromval,
    //     id:guid
    //  });
    //  idRef.current = guid;
    return ans;
  }
  // console.log("form id", fromval.id);

  function submit(e) {
    e.preventDefault();
    // console.log("the form", fromval);
    // let dataList=[];
    const formActual={...fromval,id:uidfun()};
    // console.log("formActual", formActual);
    dataList = [...dataList, {...formActual }];
    console.log("DataList", dataList);
    localStorage.setItem("localList", JSON.stringify(dataList));
    let user = JSON.parse(localStorage.getItem("localList"));
    console.log(user);
    // setSubmit(true);
    // console.log(isSubmit);
    navigate('/layout')
    fun();
    // console.log(fromval);
    setVal(initialdata);
  }

  function fun() {}
  // console.log(JSON.parse(localStorage.getItem("formdata")));
  return (
    <>
      <div className="bg-slate-200 rounded-lg xyxForm px-3">
        <h1 className="text-center">Form</h1>
        <form onSubmit={submit}>
          <div class="row row-cols-lg-3 row-cols-md-2 row-cols-sm-1">
            <div class="col">
              <label className="text-black">Name:</label>
              <InputText
                // className="w-50"
                type="text"
                name="name"
                value={fromval.name}
                onChange={Onchange}
                placeholder="Enter your name"
              />
            </div>
            <div class="col">
              <label className="text-black">Email:</label>
              <InputText
                className="w-50"
                type="mail"
                value={fromval.email}
                name="email"
                placeholder="Enter your Email"
                onChange={Onchange}
              />
            </div>
            <div class="col">
              <label className="text-black">Address:</label>
              <InputText
                className="w-50"
                type="text"
                value={fromval.address}
                name="address"
                placeholder="Enter Address"
                onChange={Onchange}
              />
            </div>
          </div>
          <div class="row mt-5">
            <div class="col">
              <span className="font-bold">DOB Choice:</span>
              <br></br>
              <div className="flex">
                <label className="text-black">DOB</label>
                <InputText
                  className="mt-3"
                  type="radio"
                  value={"dob"}
                  name="dob"
                  onChange={Onchange}
                />
                <label className="text-black">Age</label>
                <InputText
                  className="mt-3"
                  type="radio"
                  value={"age"}
                  name="dob"
                  onChange={Onchange}
                />
                <div>
                  {fromval.isdob ? (
                    <InputText
                      type="date"
                      value={fromval.dobval}
                      name="dobval"
                      onChange={Onchange}
                    />
                  ) : (
                    <InputText
                      className="w-50"
                      type="number"
                      value={fromval.dobval}
                      name="dobval"
                      onChange={Onchange}
                      // onChange={(e)=>setVal({...fromval,dob:e.target.value})}
                    />
                  )}
                </div>
              </div>
            </div>
            <div class="col">
              <label className="text-black mt-3">Date</label>
              <InputText
                className="w-50"
                type="date"
                value={fromval.dates}
                name="dates"
                onChange={Onchange}
              />
            </div>
            <div class="col">
              <label className="text-black mt-3">Upload Image</label>
              <InputText
                className="w-50"
                type="File"
                value={fromval.image}
                name="image"
                onChange={Onchange}
              />
            </div>
          </div>
          <button
            type="submit"
            className="bg-purple-800 px-5 py-2 rounded-xl text-white mt-5 text"
          >
            Submit
          </button>
        </form>
      </div>
    </>
  );
};
